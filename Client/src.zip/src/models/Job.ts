export interface Job {
    id: number;
    abbreviation: string;
    fullName: string;
    canDualWield: boolean; 
}