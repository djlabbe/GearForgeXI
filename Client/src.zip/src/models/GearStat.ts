
export interface GearStat {
    name: string;
    displayName?: string;
    category?: string;
    description?: string;
    value: number;
}
